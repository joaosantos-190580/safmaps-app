browserify L.Routing.Google.js >dist/lrm-google.js
uglifyjs dist/lrm-google.js >dist/lrm-google.min.js